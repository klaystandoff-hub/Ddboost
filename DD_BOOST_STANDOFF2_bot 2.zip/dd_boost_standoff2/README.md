# DD BOOST | STANDOFF 2 — Telegram bot starter

Telegram bot project in Python (aiogram 3) with Russian/Uzbek language selection, four service categories, order flow, manual receipt review, admin approval/rejection, user order history, SQLite storage, and admin-configured prices.

## Important
- This archive is project source, not a deployed/running bot.
- No real prices are preloaded. Set your prices before accepting orders.
- Verify the rank names against the current game version before advertising.
- Never paste the bot token into a public chat or repository. Add it only to private host secrets/environment variables.
- `ADMIN_ID` must be your numeric Telegram user ID, not your username.
- Payment receipts are reviewed manually; the bot does not verify bank transfers automatically.
- Avoid asking customers to send game account passwords. Review game rules and applicable terms before selling boosting services.

## Run
1. Use Python 3.11+.
2. Install dependencies: `pip install -r requirements.txt`
3. Copy `.env.example` to `.env` and fill in `BOT_TOKEN`, `ADMIN_ID`, and `CARD_INFO`.
4. Start: `python bot.py`

On a hosting platform, add the same values as private environment variables and run `python bot.py` as a persistent worker. Use persistent disk for `dd_boost.sqlite3`.

## Commands
- `/orders` — last 30 orders (admin)
- `/setprice rank 0 1 15000` — price for rank index 0 → 1
- `/setprice competitive 1 2 20000` — competitive service rank step
- `/setprice duels 5 0 10000` — 5 duel wins
- `/setprice rating 100 200 15000` — current rating 100 to target 200
- `/help` — command details

Rank indices follow the list in `bot.py` from 0 to 8. The price command configures exact rank/rating ranges, so set the combinations customers can choose.
