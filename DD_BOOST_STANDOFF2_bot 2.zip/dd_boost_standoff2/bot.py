import asyncio, os, sqlite3
from datetime import datetime, timezone
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv('BOT_TOKEN', '').strip()
ADMIN_ID = int(os.getenv('ADMIN_ID', '0'))
CARD_INFO = os.getenv('CARD_INFO', 'Реквизиты ещё не настроены. Напишите администратору.')
DB_PATH = os.getenv('DB_PATH', 'dd_boost.sqlite3')
if not TOKEN:
    raise RuntimeError('Добавьте BOT_TOKEN в секретные переменные хостинга или в .env')

# Rank names are editable to match the current in-game terminology.
RANKS = ['Бронза', 'Серебро', 'Золото', 'Феникс', 'Рейнджер', 'Чемпион', 'Мастер', 'Элита', 'Легенда']
SERVICES = {
    'rank': {'ru':'🏆 Буст ранга', 'uz':'🏆 Rank boost'},
    'duels': {'ru':'⚔️ Дуэли', 'uz':'⚔️ Duel'},
    'competitive': {'ru':'🎯 Соревновательный режим', 'uz':'🎯 Raqobatli rejim'},
    'rating': {'ru':'📈 Повышение рейтинга', 'uz':'📈 Reytingni oshirish'},
}
LANGS = {'ru':'🇷🇺 Русский', 'uz':'🇺🇿 O‘zbekcha'}
TEXT = {
'ru': {
'welcome':'Добро пожаловать в DD BOOST | STANDOFF 2! Выберите язык / Tilni tanlang:',
'menu':'Выберите услугу:', 'choose_rank':'Выберите текущий ранг:', 'target_rank':'Выберите желаемый ранг:',
'bad_rank':'Желаемый ранг должен быть выше текущего.', 'duel_count':'Выберите количество побед в дуэлях:',
'rating_from':'Введите текущий рейтинг числом:', 'rating_to':'Введите желаемый рейтинг числом:',
'confirm':'Проверьте заказ:', 'unpriced':'Цена для этого варианта ещё не настроена. Напишите администратору или выберите другой вариант.',
'pay':'Заказ №{oid} создан. Сумма: {price:,} сум.\nРеквизиты: {card}\n\nПосле оплаты отправьте скриншот чека сюда. Не отправляйте пароль от игрового аккаунта в этот чат.',
'receipt':'Чек отправлен администратору на проверку. Заказ №{oid}.', 'cancel':'Заказ отменён. Нажмите /start, чтобы начать заново.',
'admin_new':'🆕 Заказ №{oid}\nУслуга: {service}\nПараметры: {details}\nЦена: {price:,} сум\nКлиент: {user} (ID {uid})',
'approved':'Оплата заказа №{oid} подтверждена. Статус: принят в работу.', 'rejected':'Оплата заказа №{oid} отклонена. Свяжитесь с поддержкой, если это ошибка.',
'only_admin':'Эта команда доступна только администратору.', 'orders_empty':'Заказов пока нет.', 'send_photo':'Пожалуйста, отправьте скриншот чека фотографией.',
'need_number':'Введите положительное целое число.', 'main':'Главное меню', 'support':'По вопросам заказа напишите администратору.'},
'uz': {
'welcome':'DD BOOST | STANDOFF 2 ga xush kelibsiz! Tilni tanlang:', 'menu':'Xizmatni tanlang:',
'choose_rank':'Hozirgi rankingizni tanlang:', 'target_rank':'Qaysi rankgacha ko‘tarilmoqchisiz?',
'bad_rank':'Yakuniy rank hozirgi rankdan yuqori bo‘lishi kerak.', 'duel_count':'Duel g‘alabalari sonini tanlang:',
'rating_from':'Hozirgi reytingni raqam bilan kiriting:', 'rating_to':'Maqsad reytingni raqam bilan kiriting:',
'confirm':'Buyurtmani tekshiring:', 'unpriced':'Bu variant uchun narx hali sozlanmagan. Administrator bilan bog‘laning.',
'pay':'Buyurtma №{oid} yaratildi. Summa: {price:,} so‘m.\nTo‘lov ma’lumotlari: {card}\n\nTo‘lovdan so‘ng chek rasmini yuboring. O‘yin akkauntingiz parolini bu chatga yubormang.',
'receipt':'Chek administratorga tekshirish uchun yuborildi. Buyurtma №{oid}.', 'cancel':'Buyurtma bekor qilindi. Qayta boshlash uchun /start bosing.',
'admin_new':'🆕 Buyurtma №{oid}\nXizmat: {service}\nMa’lumot: {details}\nNarx: {price:,} so‘m\nMijoz: {user} (ID {uid})',
'approved':'№{oid} buyurtma to‘lovi tasdiqlandi.', 'rejected':'№{oid} buyurtma to‘lovi rad etildi. Xato bo‘lsa, yordamga yozing.',
'only_admin':'Bu buyruq faqat administrator uchun.', 'orders_empty':'Hozircha buyurtmalar yo‘q.', 'send_photo':'Iltimos, chek rasmini foto sifatida yuboring.',
'need_number':'Musbat butun son kiriting.', 'main':'Asosiy menyu', 'support':'Buyurtma bo‘yicha administratorga yozing.'}}

def db():
    con=sqlite3.connect(DB_PATH); con.row_factory=sqlite3.Row; return con

def init_db():
    with db() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,username TEXT,lang TEXT,service TEXT,details TEXT,price INTEGER,status TEXT,receipt_file_id TEXT,created_at TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS prices(service TEXT,kind TEXT,a INTEGER,b INTEGER,price INTEGER,PRIMARY KEY(service,kind,a,b))''')

def kb(rows): return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=x,callback_data=y) for x,y in row] for row in rows])
def tr(lang,key,**kw): return TEXT.get(lang,TEXT['ru'])[key].format(**kw)
def rank_kb(prefix, exclude=None): return kb([[(r,f'{prefix}:{i}')] for i,r in enumerate(RANKS) if i != exclude])
def service_menu(lang): return kb([[(v[lang],f'service:{k}')] for k,v in SERVICES.items()]+[[('📦 Мои заказы / Buyurtmalarim','myorders')],[('💬 Поддержка / Yordam','support')],[('🌐 Сменить язык / Tilni almashtirish','changelang')]])
def get_price(service,kind,a,b):
    with db() as c:
        row=c.execute('SELECT price FROM prices WHERE service=? AND kind=? AND a=? AND b=?',(service,kind,a,b)).fetchone()
        return int(row['price']) if row else 0

class Flow(StatesGroup):
    rank_from=State(); rank_to=State(); duel_count=State(); rating_from=State(); rating_to=State(); confirm=State(); receipt=State()

bot=Bot(TOKEN); dp=Dispatcher()

@dp.message(CommandStart())
async def start(m:Message,state:FSMContext):
    await state.clear(); await m.answer(TEXT['ru']['welcome'],reply_markup=kb([[('🇷🇺 Русский','lang:ru'),('🇺🇿 O‘zbekcha','lang:uz')]]))

@dp.callback_query(F.data.startswith('lang:'))
async def lang_choice(q:CallbackQuery,state:FSMContext):
    lang=q.data.split(':')[1]; await state.update_data(lang=lang)
    await q.message.edit_text(tr(lang,'menu'),reply_markup=service_menu(lang)); await q.answer()

@dp.callback_query(F.data=='changelang')
async def change_lang(q:CallbackQuery,state:FSMContext):
    await q.message.edit_text(TEXT['ru']['welcome'],reply_markup=kb([[('🇷🇺 Русский','lang:ru'),('🇺🇿 O‘zbekcha','lang:uz')]])); await q.answer()

@dp.callback_query(F.data.startswith('service:'))
async def choose_service(q:CallbackQuery,state:FSMContext):
    service=q.data.split(':',1)[1]; data=await state.get_data(); lang=data.get('lang','ru')
    await state.update_data(service=service)
    if service in ('rank','competitive'):
        await state.set_state(Flow.rank_from); await q.message.edit_text(tr(lang,'choose_rank'),reply_markup=rank_kb('rf'))
    elif service=='duels':
        await state.set_state(Flow.duel_count); await q.message.edit_text(tr(lang,'duel_count'),reply_markup=kb([[('1 победа','duel:1'),('3 победы','duel:3')],[('5 побед','duel:5'),('10 побед','duel:10')]]))
    else:
        await state.set_state(Flow.rating_from); await q.message.edit_text(tr(lang,'rating_from'))
    await q.answer()

@dp.callback_query(Flow.rank_from,F.data.startswith('rf:'))
async def rank_from(q:CallbackQuery,state:FSMContext):
    a=int(q.data.split(':')[1]); await state.update_data(a=a); data=await state.get_data(); lang=data.get('lang','ru')
    await state.set_state(Flow.rank_to); await q.message.edit_text(tr(lang,'target_rank'),reply_markup=rank_kb('rt',exclude=a)); await q.answer()

@dp.callback_query(Flow.rank_to,F.data.startswith('rt:'))
async def rank_to(q:CallbackQuery,state:FSMContext):
    b=int(q.data.split(':')[1]); data=await state.get_data(); lang=data.get('lang','ru'); a=data['a']
    if b<=a: await q.answer(tr(lang,'bad_rank'),show_alert=True); return
    service=data['service']; price=get_price(service,'rank',a,b)
    if not price: await q.answer(tr(lang,'unpriced'),show_alert=True); return
    details=f'{RANKS[a]} → {RANKS[b]}'
    await show_confirm(q,state,service,details,price)

@dp.callback_query(Flow.duel_count,F.data.startswith('duel:'))
async def duel_count(q:CallbackQuery,state:FSMContext):
    wins=int(q.data.split(':')[1]); data=await state.get_data(); lang=data.get('lang','ru'); price=get_price('duels','wins',wins,0)
    if not price: await q.answer(tr(lang,'unpriced'),show_alert=True); return
    await show_confirm(q,state,'duels',f'{wins} побед(ы) в дуэлях',price)

@dp.message(Flow.rating_from)
async def rating_from(m:Message,state:FSMContext):
    try: a=int(m.text.strip()); assert a>=0
    except: await m.answer(tr((await state.get_data()).get('lang','ru'),'need_number')); return
    await state.update_data(a=a); lang=(await state.get_data()).get('lang','ru'); await state.set_state(Flow.rating_to); await m.answer(tr(lang,'rating_to'))

@dp.message(Flow.rating_to)
async def rating_to(m:Message,state:FSMContext):
    try: b=int(m.text.strip()); assert b>0
    except: await m.answer(tr((await state.get_data()).get('lang','ru'),'need_number')); return
    data=await state.get_data(); lang=data.get('lang','ru'); a=data['a']
    if b<=a: await m.answer(tr(lang,'bad_rank')); return
    price=get_price('rating','points',a,b)
    if not price: await m.answer(tr(lang,'unpriced')); return
    await state.update_data(b=b); await send_confirm_message(m,state,'rating',f'{a} → {b} рейтинга',price)

async def show_confirm(q,state,service,details,price):
    await state.update_data(details=details,price=price); data=await state.get_data(); lang=data.get('lang','ru')
    await state.set_state(Flow.confirm)
    txt=f"{tr(lang,'confirm')}\nУслуга: {SERVICES[service][lang]}\n{details}\nЦена: {price:,} {'сум' if lang=='ru' else 'so‘m'}"
    await q.message.edit_text(txt,reply_markup=kb([[('✅ Оформить / Tasdiqlash','order:yes')],[('❌ Отмена / Bekor qilish','order:no')]])); await q.answer()

async def send_confirm_message(m,state,service,details,price):
    await state.update_data(service=service,details=details,price=price); data=await state.get_data(); lang=data.get('lang','ru'); await state.set_state(Flow.confirm)
    await m.answer(f"{tr(lang,'confirm')}\nУслуга: {SERVICES[service][lang]}\n{details}\nЦена: {price:,} {'сум' if lang=='ru' else 'so‘m'}",reply_markup=kb([[('✅ Оформить / Tasdiqlash','order:yes')],[('❌ Отмена / Bekor qilish','order:no')]]))

@dp.callback_query(Flow.confirm,F.data=='order:no')
async def cancel(q:CallbackQuery,state:FSMContext):
    data=await state.get_data(); await state.clear(); await q.message.edit_text(tr(data.get('lang','ru'),'cancel')); await q.answer()

@dp.callback_query(Flow.confirm,F.data=='order:yes')
async def order_yes(q:CallbackQuery,state:FSMContext):
    data=await state.get_data(); u=q.from_user; lang=data.get('lang','ru')
    with db() as c:
        cur=c.execute('INSERT INTO orders(user_id,username,lang,service,details,price,status,created_at) VALUES(?,?,?,?,?,?,?,?)',(u.id,u.username,lang,data['service'],data['details'],data['price'],'awaiting_receipt',datetime.now(timezone.utc).isoformat()))
        oid=cur.lastrowid
    await state.update_data(order_id=oid); await state.set_state(Flow.receipt)
    await q.message.edit_text(tr(lang,'pay',oid=oid,price=data['price'],card=CARD_INFO)); await q.answer()

@dp.message(Flow.receipt,F.photo)
async def receipt(m:Message,state:FSMContext):
    data=await state.get_data(); oid=data['order_id']; fid=m.photo[-1].file_id; u=m.from_user
    with db() as c: c.execute("UPDATE orders SET status='pending_review',receipt_file_id=? WHERE id=?",(fid,oid))
    lang=data.get('lang','ru'); service=SERVICES[data['service']][lang]
    if ADMIN_ID:
        caption=tr(lang,'admin_new',oid=oid,service=service,details=data['details'],price=data['price'],user='@'+u.username if u.username else 'без username',uid=u.id)
        await bot.send_photo(ADMIN_ID,fid,caption=caption,reply_markup=kb([[('✅ Подтвердить',f'admin:approve:{oid}'),('❌ Отклонить',f'admin:reject:{oid}')]]))
    await m.answer(tr(lang,'receipt',oid=oid)); await state.clear()

@dp.message(Flow.receipt)
async def receipt_not_photo(m:Message,state:FSMContext): await m.answer(tr((await state.get_data()).get('lang','ru'),'send_photo'))

@dp.callback_query(F.data.startswith('admin:'))
async def admin_action(q:CallbackQuery):
    if q.from_user.id!=ADMIN_ID: await q.answer('Только администратор.',show_alert=True); return
    _,action,raw=q.data.split(':'); oid=int(raw)
    with db() as c:
        row=c.execute('SELECT * FROM orders WHERE id=?',(oid,)).fetchone()
        if not row: await q.answer('Заказ не найден.',show_alert=True); return
        status='accepted' if action=='approve' else 'payment_rejected'; c.execute('UPDATE orders SET status=? WHERE id=?',(status,oid))
    await bot.send_message(row['user_id'],tr(row['lang'],'approved' if action=='approve' else 'rejected',oid=oid))
    try: await q.message.edit_caption((q.message.caption or '')+f'\n\nСтатус: {status}')
    except: pass
    await q.answer('Готово')

@dp.callback_query(F.data=='myorders')
async def myorders(q:CallbackQuery,state:FSMContext):
    data=await state.get_data(); lang=data.get('lang','ru')
    with db() as c: rows=c.execute('SELECT id,service,details,price,status FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 10',(q.from_user.id,)).fetchall()
    if not rows: txt=tr(lang,'orders_empty')
    else:
        txt='📦 Мои заказы:\n'+'\n'.join(f"№{r['id']} · {SERVICES.get(r['service'],{}).get(lang,r['service'])}\n{r['details']} · {r['price']:,} сум\nСтатус: {r['status']}" for r in rows)
    await q.message.edit_text(txt,reply_markup=kb([[('⬅️ '+tr(lang,'main'),'backmenu')]])); await q.answer()

@dp.callback_query(F.data=='backmenu')
async def backmenu(q:CallbackQuery,state:FSMContext):
    data=await state.get_data(); lang=data.get('lang','ru'); await q.message.edit_text(tr(lang,'menu'),reply_markup=service_menu(lang)); await q.answer()

@dp.callback_query(F.data=='support')
async def support(q:CallbackQuery,state:FSMContext):
    lang=(await state.get_data()).get('lang','ru'); await q.answer(tr(lang,'support'),show_alert=True)

@dp.message(Command('orders'))
async def admin_orders(m:Message):
    if m.from_user.id!=ADMIN_ID: await m.answer('Только для администратора.'); return
    with db() as c: rows=c.execute('SELECT * FROM orders ORDER BY id DESC LIMIT 30').fetchall()
    if not rows: await m.answer('Заказов пока нет.'); return
    lines=['Последние заказы:']
    for r in rows: lines.append(f"№{r['id']} | {r['status']} | {r['price']:,} сум | {SERVICES.get(r['service'],{}).get('ru',r['service'])} | {r['details']} | user {r['user_id']}")
    await m.answer('\n'.join(lines))

@dp.message(Command('setprice'))
async def setprice(m:Message):
    if m.from_user.id!=ADMIN_ID: await m.answer('Только для администратора.'); return
    p=(m.text or '').split()
    if len(p)!=5:
        await m.answer('Формат: /setprice rank|competitive|rating|duels A B PRICE\nrank/competitive: A и B — индексы рангов 0–8; rating: A=текущий рейтинг, B=целевой; duels: A=число побед, B=0.\nПример: /setprice rank 0 1 15000'); return
    _,service,a,b,price=p
    try: a,b,price=int(a),int(b),int(price)
    except: await m.answer('A, B и цена должны быть числами.'); return
    if service not in ('rank','competitive','rating','duels') or a<0 or b<0 or price<=0 or (service in ('rank','competitive') and not (a<b<len(RANKS))):
        await m.answer('Некорректные значения. Цена должна быть больше 0.'); return
    kind={'rank':'rank','competitive':'rank','rating':'points','duels':'wins'}[service]
    with db() as c: c.execute('INSERT INTO prices(service,kind,a,b,price) VALUES(?,?,?,?,?) ON CONFLICT(service,kind,a,b) DO UPDATE SET price=excluded.price',(service,kind,a,b,price))
    await m.answer(f'Цена сохранена: {service} {a} → {b} = {price:,} сум.')

@dp.message(Command('help'))
async def help_cmd(m:Message):
    await m.answer('Команды администратора:\n/orders — последние заказы\n/setprice SERVICE A B PRICE — установить цену\n\nДля rank/competitive A и B — индексы рангов 0–8. Для duels A — число побед, B=0. Для rating A — текущий рейтинг, B — целевой.\nЦены не заданы заранее: внесите свой прайс перед запуском продаж.')

async def main():
    init_db()
    await dp.start_polling(bot)
if __name__=='__main__': asyncio.run(main())
